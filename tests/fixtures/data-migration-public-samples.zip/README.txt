Public SEC/CFTC samples retrieved 2026-09-13 UTC for bounded migration verification.
See source-audit.json for source URLs, retrieval times, sizes, and SHA256.
These are evidence fixtures, not live data or a complete CFTC raw-history archive.
Extract locally and run scripts/data-migration-load.mjs --samples=/absolute/extracted/samples.
No credentials or portfolio/user data included.
